# lanndingPage-Rildo
Projeto criado como critério para 2ª A.V. Na faculdade. É sobre a 2ª Igreja Batista Reformada em Paulista.
